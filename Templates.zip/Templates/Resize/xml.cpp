#include <iostream>
#include <string>
#include <experimental/filesystem>
#include <thread>
#include <future>
#include <boost/pool/pool.hpp>
#include <boost/log/trivial.hpp>

namespace fs = std::experimental::filesystem;

void find_images(const fs::path &folder, const fs::path &root, boost::pool<> &memory_pool) {
    try {
        
    } catch (const fs::filesystem_error &ex) {
        BOOST_LOG_TRIVIAL(error) << "File system error: " << ex.what();
    } catch (const std::exception &ex) {
        BOOST_LOG_TRIVIAL(error) << "Error: " << ex.what();
    }
}

int main() {
    std::cout << "Enter the path of the folder: ";
    std::string folder_path;
    std::getline(std::cin, folder_path);

    std::cout << "Enter the name of the root folder: ";
    std::string root_folder;
    std::getline(std::cin, root_folder);

    fs::path folder(folder_path);
    fs::path root(root_folder);

    if (!fs::exists(root)) {
        fs::create_directory(root);
    }

    // Create a memory pool with a fixed block size
    boost::pool<> memory_pool(sizeof(SomeType));

    // Initialize the logging
    boost::log::add_file_log("errors.log");
    boost::log::core::get()->set_filter(boost::log::trivial::severity >= boost::log::trivial::error);

    unsigned int thread_count = std::thread::hardware_concurrency();
    std::vector<std::future<void>> futures;
    for (unsigned int i = 0; i < thread_count; i++) {
        futures.emplace_back(std::async(std::launch::async, find_images, folder, root, std::ref(memory_pool)));
    }
    for (auto &f : futures) {
        f.get();
    }
    return 0;
}
