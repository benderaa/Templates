class ProgressIndicator
{
    // time at which the progress indicator was started
    std::chrono::time_point<std::chrono::steady_clock> start_time;

public:
    ProgressIndicator()
    {
        start_time = std::chrono::steady_clock::now();
    }

    void showProgress(int current, int total)
    {
        // calculate the percentage of completion
        int percent = (current * 100) / total;

        // calculate the elapsed time
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start_time).count();
        // estimate the remaining time
        auto remaining = (elapsed * (100 - percent)) / percent;

        std::cout << "\r" << percent << "% complete, remaining time: " << remaining << " ms" << std::flush;
    }
};
