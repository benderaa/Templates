#include <thread>

class Threading
{
public:
    static void resizeImage(std::string input_file, std::string output_file, double width, double height);
};
