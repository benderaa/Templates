#include <Windows.h>
#include <boost/program_options.hpp>

class CommandLineArgs
{
public:
    CommandLineArgs(int argc, char *argv[]);
    std::string getInputFile() { return input_file; }
    std::string getOutputFile() { return output_file; }
    double getWidth() { return width; }
    double getHeight() { return height; }
    std::string getOutputFormat() { return output_format; } // new function to get output format
private:
    std::string input_file;
    std::string output_file;
    double width;
    double height;
    std::string output_format; // new variable to store output format
};
