#include "Threading.h"
#include <opencv2/opencv.hpp>

using namespace cv;

void Threading::resizeImage(std::string input_file, std::string output_file, double width, double height)
{
    Mat original, resized;
    original = imread(input_file, cv::IMREAD_COLOR);
    resize(original, resized, Size(width, height), 0, 0, INTER_CUBIC);
    imwrite(output_file, resized);
}
