#include <iostream>
#include <Windows.h>
#include <wincodec.h>
#include "ImageResizer.h"
#include "ValidateInput.h"
#include "CommandLineArgs.h"
#include "Threading.h"



int main(int argc, char* argv[]) {
   
    CommandLineArgs cmd_args(argc, argv);
    std::string input_file = cmd_args.getInputFile();
    std::string output_file = cmd_args.getOutputFile();
    double width = cmd_args.getWidth();
    double height = cmd_args.getHeight();

    double width, height;
    cout << "Enter the new width: ";
    cin >> width;
    if (!ValidateInput::isValidWidth(width))
    {
        return 1;
    }
    cout << "Enter the new height: ";
    cin >> height;
     if (!ValidateInput::isValidHeight(height))
    {
        return 1;
    }

    // Threading

    vector<thread> threads;
    for (const auto& entry : std::filesystem::directory_iterator(folder_path)) {
        if (!entry.path().has_extension() || entry.path().extension() != ".png") {
            std::cout << "Error: Invalid file type." << endl;
            continue;
        }
        string input_file = entry.path();
        string output_file = "resized/" + entry.path().filename();
        threads.push_back(thread(Threading::resizeImage, input_file, output_file, width, height));
    }

    // Wait for all threads to finish
    for (auto& t : threads) {
        t.join();
    }


    //Calculate the aspect ratio of the original image
    double aspectRatio = ImageResizer::calculateAspectRatio(width, height);

    //Calculate the new width and height of the resized image
    width = width * aspectRatio;
    height = height * aspectRatio;

    // Initialize the COM library
    CoInitialize(NULL);

    // Create a WIC factory
    IWICImagingFactory *pWICFactory = NULL;
    HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_IWICImagingFactory, (LPVOID*)&pWICFactory);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC factory" << endl;
        return 1;
    }

    // Create a WIC bitmap decoder
    IWICBitmapDecoder *pDecoder = NULL;
    hr = pWICFactory->CreateDecoderFromFilename(L"input.png", NULL, GENERIC_READ, WICDecodeMetadataCacheOnLoad, &pDecoder);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC decoder" << endl;
        return 1;
    }
    // Create a WIC bitmap decoder
    IWICBitmapDecoder *pDecoder = NULL;
    hr = pWICFactory->CreateDecoderFromFilename(L"input.png", NULL, GENERIC_READ, WICDecodeMetadataCacheOnLoad, &pDecoder);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC decoder" << endl;
        return 1;
    }
    // Create a WIC bitmap frame
    IWICBitmapFrameDecode *pFrame = NULL;
    hr = pDecoder->GetFrame(0, &pFrame);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC frame" << endl;
        return 1;
    }
    // Create a WIC bitmap scaler
    IWICBitmapScaler *pScaler = NULL;
    hr = pWICFactory->CreateBitmapScaler(&pScaler);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC scaler" << endl;
        return 1;
    }
    hr = pScaler->Initialize(pFrame, width, height, WICBitmapInterpolationModeCubic);
    if (FAILED(hr))
    {
        cout<<"Error initializing WIC scaler" << endl;
        return 1;
    }
    // Create a WIC bitmap encoder
    IWICBitmapEncoder *pEncoder = NULL;
    hr = pWICFactory->CreateEncoder(GUID_ContainerFormatPng, NULL, &pEncoder);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC encoder" << endl;
        return 1;
    }
    // Create a WIC stream
    IWICStream *pStream = NULL;
    hr = pWICFactory->CreateStream(&pStream);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC stream" << endl;
        return 1;
    }
    hr = pStream->InitializeFromFilename(L"output.png", GENERIC_WRITE);
    if (FAILED(hr))
    {   cout<<"Error initializing WIC stream" << endl;
        return 1;
    }
// Initialize the encoder
    hr = pEncoder->Initialize(pStream, WICBitmapEncoderNoCache);
    if (FAILED(hr))
    {
        cout<<"Error initializing WIC encoder" << endl;
        return 1;
    }

    // Create a WIC bitmap frame
    IWICBitmapFrameEncode *pFrameEncode = NULL;
    hr = pEncoder->CreateNewFrame(&pFrameEncode, NULL);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC frame for encoder" << endl;
        return 1;
    }

    // Set the encoder properties
    hr = pFrameEncode->Initialize(NULL);
    if (FAILED(hr))
    {
        cout<<"Error initializing WIC frame for encoder" << endl;
        return 1;
    }
    hr = pFrameEncode->SetSize(width, height);
    if (FAILED(hr))
    {
        cout<<"Error setting size for WIC frame for encoder" << endl;
        return 1;
    }
    hr = p FrameEncode->SetResolution(96, 96);
    if (FAILED(hr))
      {
        cout<<"Error setting resolution for WIC frame for encoder" << endl;
        return 1;
    }
    hr = pFrameEncode->SetPixelFormat(&GUID_WICPixelFormat32bppBGRA);
    if (FAILED(hr))
    {
        cout<<"Error setting pixel format for WIC frame for encoder" << endl;
        return 1;
    }

    // Write the image data to the encoder
    hr = pFrameEncode->WriteSource(pScaler, NULL);
    if (FAILED(hr))
    {
        cout<<"Error writing source to WIC frame for encoder" << endl;
        return 1;
    }

    // Commit the encoder
    hr = pFrameEncode->Commit();
    if (FAILED(hr))
    {
        cout<<"Error committing WIC frame for encoder" << endl;
        return 1;
    }
    hr = pEncoder->Commit();
    if (FAILED(hr))
    {
        cout<<"Error committing WIC encoder" << endl;
        return 1;
    }

    // Clean up
    pStream-> Release();
    pFrameEncode->Release();
    pEncoder->Release();
    pScaler->Release();
    pFrame->Release();
    pDecoder->Release();
    pWICFactory->Release();

    // Uninitialize the COM library
    CoUninitialize();

    return 0;
}
