#include <Windows.h>
#include "CommandLineArgs.h"
#include <boost/program_options.hpp>

CommandLineArgs::CommandLineArgs(int argc, char *argv[])
{
   
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 10); // 10 for green

    namespace po = boost::program_options;

    po::options_description desc("Allowed options");
    desc.add_options()
        ("help,h", "produce help message")
        ("input-file,i", po::value<std::string>(&input_file), "input file")
        ("output-file,o", po::value<std::string>(&output_file), "output file")
        ("width,w", po::value<double>(&width)->default_value(1024), "width")
        ("height,h", po::value<double>(&height)->default_value(768), "height");
    	("output-format,f", po::value<std::string>(&output_format)->default_value("png"), "output file format (png, jpeg, bmp, etc.)");

    po::variables_map vm;
    po::store(po::parse_command_line(argc, argv, desc), vm);
    po::notify(vm);

    if (vm.count("help"))
    {
        std::cout << desc << "\n";
        exit(0);
    }

    if (!vm.count("input-file"))
    {   
        SetConsoleTextAttribute(hConsole, 15); // 15 for white
        std::cout << "Error: input file is required. Use -i or --input-file option to specify the input file." << std::endl;
        exit(1);
    }

    if (!vm.count("output-file"))
    {   
        SetConsoleTextAttribute(hConsole, 15); // 15 for white
        std::cout << "Error: output file is required. Use -o or --output-file option to specify the output file." << std::endl;
        exit(1);
    }

        SetConsoleTextAttribute(hConsole, 15); // 15 for white

}
