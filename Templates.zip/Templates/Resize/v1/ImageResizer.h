#pragma once
#include <Windows.h>
#include <wincodec.h>

class ImageResizer
{
public:
    ImageResizer();
    ~ImageResizer();

    void resizeImage(const WCHAR* inputFile, const WCHAR* outputFile, double targetWidth, double targetHeight);

private:
    double calculateAspectRatio(double width, double height);
};
