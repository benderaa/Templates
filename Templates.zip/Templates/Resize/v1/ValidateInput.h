#include <iostream>

class ValidateInput
{
public:
    static bool isValidWidth(double width)
    {
        if (width <= 0)
        {
            std::cout << "Error: Invalid width value. Width must be greater than 0." << std::endl;
            return false;
        }
        if (width / 2 != floor(width / 2))
        {
            std::cout << "Error: Invalid width value. Width must be divisible by 2." << std::endl;
            return false;
        }
        return true;
    }

    static bool isValidHeight(double height)
    {
        if (height <= 0)
        {
            std::cout << "Error: Invalid height value. Height must be greater than 0." << std::endl;
            return false;
        }
        if (height / 2 != floor(height / 2))
        {
            std::cout << "Error: Invalid height value. Height must be divisible by 2." << std::endl;
            return false;
        }
        return true;
    }
};