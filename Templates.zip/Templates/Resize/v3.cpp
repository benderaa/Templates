#include <iostream>
#include <string>
#include <experimental/filesystem>
#include <thread>
#include <future>
#include <boost/pool/pool.hpp>
#include <boost/log/trivial.hpp>
#include "Trie.h"
#include <algorithm>
#include <vector>

namespace fs = std::experimental::filesystem;

// Function that uses a Trie to search for strings containing ".img" in the files
void find_images(const fs::path &folder, Trie &trie) {
    for (const auto &entry : fs::recursive_directory_iterator(folder)) {
        if (!fs::is_regular_file(entry)) {
            continue;
        }
        std::ifstream file(entry.path().string());
        std::string line;
        while (getline(file, line)) {
            size_t pos = line.find(".img");
            if (pos != std::string::npos) {
                trie.insert(line);
            }
        }
    }
}

int main() {
    std::cout << "Enter the path of the folder: ";
    std::string folder_path;
    std::getline(std::cin, folder_path);

    fs::path folder(folder_path);

    Trie trie;

