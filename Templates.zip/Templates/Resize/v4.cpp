#include <iostream>
#include <string>
#include <fstream>
#include <experimental/filesystem>
#include <regex>
#include <map>

namespace fs = std::experimental::filesystem;

std::map<std::string, std::tuple<int, int, std::string>> results;

void update_coordinates(std::string &line, int x, int y) {
    std::regex x_regex("x=\\\"(.*?)\\\"");
    line = std::regex_replace(line, x_regex, "x=\"" + std::to_string(x) + "\"");
    std::regex y_regex("y=\\\"(.*?)\\\"");
    line = std::regex_replace(line, y_regex, "y=\"" + std::to_string(y) + "\"");
}

int main() {
    std::cout << "Enter the path of the folder: ";
    std::string folder_path;
    std::getline(std::cin, folder_path);

    fs::path folder(folder_path);

    for (const auto &entry : fs::recursive_directory_iterator(folder)) {
        if (!fs::is_regular_file(entry)) {
            continue;
        }
        std::ifstream file(entry.path().string());
        std::string line;
        std::string file_contents;
        while (getline(file, line)) {
            std::regex component("<Component(.*?)>(.*?)<\\/Component>");
            std::smatch match;
            if (std::regex_search(line, match, component)) {
                std::string component_info = match[1];
                std::regex x("x=\\\"(.*?)\\\"");
                std::smatch x_match;
                if (std::regex_search(component_info, x_match, x)) {
                    int x_coord = std::stoi(x_match[1]);
                    std::regex y("y=\\\"(.*?)\\\"");
                    std::smatch y_match;
                    if (std::regex_search(component_info, y_match, y)) {
                        int y_coord = std::stoi(y_match[1]);
                        results[entry.path().string()] = std::make_tuple(x_coord, y_coord, "");
                        update_coordinates(line, x_coord+10, y_coord+10);
                    }
                }
            }
            file_contents += line + "\n";
        }
        file.close();
        std::ofstream outfile(entry.path().string());
        outfile << file_contents;
        outfile.close();
    }
    for (const auto &result : results) {
        std::cout << "File: " << std::get<2>(
                result.second) << " X: " << std::get<0>(result.second) << " Y: " << std::get<1>(result.second)
                  << std::endl;
    }
};