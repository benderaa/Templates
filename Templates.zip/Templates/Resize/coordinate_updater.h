#pragma once
#include <string>
#include <regex>

void update_coordinates(std::string &line, int x, int y) {
    std::regex x_regex("x=\\\"(.*?)\\\"");
    line = std::regex_replace(line, x_regex, "x=\"" + std::to_string(x) + "\"");
    std::regex y_regex("y=\\\"(.*?)\\\"");
    line = std::regex_replace(line, y_regex, "y=\"" + std::to_string(y) + "\"");
}
