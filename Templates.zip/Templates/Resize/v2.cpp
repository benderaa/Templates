#include <iostream>
#include <Windows.h>
#include <wincodec.h>
#include "ImageResizer.h"
#include "ValidateInput.h"
#include "CommandLineArgs.h"
#include "Threading.h"
#include <ncurses.h>
#include <filesystem>
#include <fstream>

int main(int argc, char* argv[]) {

    CommandLineArgs cmd_args(argc, argv);
    std::string input_file = cmd_args.getInputFile();
    std::string output_file = cmd_args.getOutputFile();
    double width = cmd_args.getWidth();
    double height = cmd_args.getHeight();

    double width, height;
    cout << "Enter the new width: ";
    cin >> width;
    if (!ValidateInput::isValidWidth(width))
    {
        return 1;
    }
    cout << "Enter the new height: ";
    cin >> height;
    if (!ValidateInput::isValidHeight(height))
    {
        return 1;
    }

    //Initialize ncurses
    initscr();
    cbreak();
    noecho();

    // Threading
    int total_images = std::count_if(std::filesystem::directory_iterator(folder_path), std::filesystem::directory_iterator(), [](const std::filesystem::directory_entry& e) {return e.path().has_extension() && e.path().extension() == ".png"; });
    int current_image = 0;
    vector<thread> threads;
    for (const auto& entry : std::filesystem::directory_iterator(folder_path)) {
        if (!entry.path().has_extension() || entry.path().extension() != ".png") {
            std::cout << "Error: Invalid file type." << endl;
            continue;
        }
        string input_file = entry.path();
        string output_file = "resized/" + entry.path().filename();
        threads.push_back(thread(Threading::resizeImage, input_file, output_file, width, height, current_image, total_images));
        current_image++;
    }

    // Wait for all threads to finish
    for (auto& t : threads) {
        t.join();
    }

    updateXML("config.xml", output_file); {

        void updateXML(const std::string& xmlFile, const std::string& outputFile) {
    std::string line;
    std::string newLine = "new_output_file=" + outputFile;
    std::string tempFile = "temp.xml";
    std::fstream source(xmlFile, std::ios::in);
    std::fstream temp(tempFile, std::ios::out);
    while (getline(source, line)) {
        if (line.substr(0, 17) == "new_output_file=") {
            temp << newLine << std::endl;
        } else {
            temp << line << std::endl;
        }
    }
    source.close();
    temp.close();
    std::remove(xmlFile.c_str());
    std::rename(tempFile.c_str(), xmlFile.c_str());
}


    }


    // Calculate the aspect ratio of the original image
    double aspectRatio = ImageResizer::calculateAspectRatio(width, height);

    // Calculate the new width and height of the resized image
    width = width * aspectRatio;
    height = height * aspectRatio;

    // Initialize the COM library
    CoInitialize(NULL);

    // Create a WIC factory
    IWICImagingFactory *pWICFactory = NULL;
    HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_IWICImagingFactory, (LPVOID*)&pWICFactory);
    if (FAILED(hr))
   
{
        cout<<"Error creating WIC factory" << endl;
        return 1;
    }

    // Create a WIC bitmap decoder
    IWICBitmapDecoder *pDecoder = NULL;
    hr = pWICFactory->CreateDecoderFromFilename(L"input.png", NULL, GENERIC_READ, WICDecodeMetadataCacheOnLoad, &pDecoder);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC decoder" << endl;
        return 1;
    }
    // Create a WIC bitmap frame
    IWICBitmapFrameDecode *pFrame = NULL;
    hr = pDecoder->GetFrame(0, &pFrame);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC frame" << endl;
        return 1;
    }
    // Create a WIC bitmap scaler
    IWICBitmapScaler *pScaler = NULL;
    hr = pWICFactory->CreateBitmapScaler(&pScaler);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC scaler" << endl;
        return 1;
    }
    hr = pScaler->Initialize(pFrame, width, height, WICBitmapInterpolationModeCubic);
    if (FAILED(hr))
    {
        cout<<"Error initializing WIC scaler" << endl;
        return 1;
    }

    // Create a WIC bitmap encoder
    IWICBitmapEncoder *pEncoder = NULL;
    hr = pWICFactory->CreateEncoder(GUID_ContainerFormatPng, NULL, &pEncoder);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC encoder" << endl;
        return 1;
    }
    // Create a WIC stream
    IWICStream *pStream = NULL;
    hr = pWICFactory->CreateStream(&pStream);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC stream" << endl;
        return 1;
    }
    hr = pStream->InitializeFromFilename(L"output.png", GENERIC_WRITE);
    if (FAILED(hr))
    {
        cout<<"Error initializing WIC stream" << endl;
        return 1;
    }
    // Initialize the encoder
    hr = pEncoder->Initialize(pStream, WICBitmapEncoderNoCache);
    if (FAILED(hr))
    {
        cout<<"Error initializing WIC encoder" << endl;
        return 1;
    }
    // Create a WIC bitmap frame
    IWICBitmapFrameEncode *pFrameEncode = NULL;
    hr = pEncoder->CreateNewFrame(&pFrameEncode, NULL);
    if (FAILED(hr))
    {
        cout<<"Error creating WIC frame for encoding" << endl;
        return 1;
    }

        // Initialize the frame
    hr = pFrameEncode->Initialize(NULL);
    if (FAILED(hr))
    {
        cout<<"Error initializing WIC frame for encoding" << endl;
        return 1;
    }
    // Set the pixel format
    hr = pFrameEncode->SetPixelFormat(&GUID_WICPixelFormat24bppBGR);
    if (FAILED(hr))
    {
        cout<<"Error setting pixel format" << endl;
        return 1;
    }
    // Write the pixels
    hr = pFrameEncode->WritePixels(height, width, width * 3, (BYTE*)pixels);
    if (FAILED(hr))
    {
        cout<<"Error writing pixels" << endl;
        return 1;
    }
    // Commit the frame
    hr = pFrameEncode->Commit();
    if (FAILED(hr))
    {
        cout<<"Error committing frame" << endl;
        return 1;
    }
    // Commit the encoder
    hr = pEncoder->Commit();
    if (FAILED(hr))
    {
        cout<<"Error committing encoder" << endl;
        return 1;
    }
    // Release the resources
    pScaler->Release();
    pFrame->Release();
    pDecoder->Release();
    pWICFactory->Release();
    CoUninitialize();

    // End ncurses mode
    endwin();

    return 0;
}

void Threading::resizeImage(string input_file, string output_file, double width, double height, int current_image, int total_images)
{
 
    move(0,0);
    int progress = (100*current_image/total_images);
    mvprintw(0,0,"Progress: [");
    for(int i=0;i<progress;i++) mvprintw(0,"#");
    for(int i=progress;i<100;i++) mvprintw(0," ");
    mvprintw(0,"] %d%%",progress);
    refresh();
}
