using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();
        var exception = exceptionHandlerPathFeature.Error;

        if (exception is ArgumentException)
        {
            context.Response.StatusCode = StatusCodes.Status400BadRequest;
        }
        else
        {
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        }

        await context.Response.WriteAsync(exception.Message);
    });
});

app.MapGet("/", async context =>
{
    await context.Response.WriteAsync(" Dogukans API!");
});

app.MapGet("/items", (List<Item> items) => items);

app.MapGet("/items/{id}", (List<Item> items, int id) =>
{
var item = items.FirstOrDefault(i => i.Id == id);
if (item == null)
{
return Results.NotFound($"Item with ID {id} not found.");
}
return item;
});

app.MapPost("/items", (List<Item> items, CreateItemDto newItem) =>
{
var validationResult = Validate(newItem);
if (validationResult != null)
{
throw new ArgumentException(validationResult.ErrorMessage);
}
int newId = items.Count > 0 ? items.Max(i => i.Id) + 1 : 1;
var item = new Item(newId, newItem.Name, newItem.Description);
items.Add(item);
return Results.Created($"/items/{item.Id}", item);
});

app.MapPut("/items/{id}", (List<Item> items, int id, UpdateItemDto updatedItem) =>
{
var validationResult = Validate(updatedItem);
if (validationResult != null)
{
throw new ArgumentException(validationResult.ErrorMessage);
}

var item = items.FirstOrDefault(i => i.Id == id);
if (item == null)
{
    return Results.NotFound($"Item with ID {id} not found.");
}

var updated = item with { Name = updatedItem.Name, Description = updatedItem.Description };
items[items.IndexOf(item)] = updated;
return Results.NoContent
